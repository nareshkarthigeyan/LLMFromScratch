# Data missing?
If you are looking for the training data. I have not included it for many reasons including:
- Storage (They're big)
- Privacy
- I'm Lazy

Try importing your own datasets if plan on cloning this and playing with it yourself.